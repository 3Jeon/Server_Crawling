package _3jeon.server;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JsoupCrawlingApplication {

    public static void main(String[] args) {
        SpringApplication.run(JsoupCrawlingApplication.class, args);
    }

}
