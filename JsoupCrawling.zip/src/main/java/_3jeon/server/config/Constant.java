package _3jeon.server.config;

public class Constant {
}

