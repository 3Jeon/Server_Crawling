package _3jeon.server.config.secret;

public class Secret {
    // 임의의 JWT 키 발급
    public static String YOGIYO_API_SECRET = "fe5183cc3dea12bd0ce299cf110a75a2";
    public static String YOGIYO_API_KEY = "iphoneap";
}