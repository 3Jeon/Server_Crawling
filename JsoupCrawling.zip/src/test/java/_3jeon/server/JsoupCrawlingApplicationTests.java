package _3jeon.server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JsoupCrawlingApplicationTests {

    @Test
    void contextLoads() {
    }

}
